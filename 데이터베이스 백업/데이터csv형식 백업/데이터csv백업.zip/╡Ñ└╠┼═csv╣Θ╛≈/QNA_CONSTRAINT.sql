--------------------------------------------------------
--  Constraints for Table QNA
--------------------------------------------------------

  ALTER TABLE "QNA" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "QNA" MODIFY ("QNA_NUM" NOT NULL ENABLE);
  ALTER TABLE "QNA" ADD CONSTRAINT "QNA_PK" PRIMARY KEY ("USER_ID", "QNA_NUM")
  USING INDEX (CREATE UNIQUE INDEX "PK_QNA" ON "QNA" ("USER_ID", "QNA_NUM") 
  )  ENABLE;
