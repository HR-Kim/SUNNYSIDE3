--------------------------------------------------------
--  Constraints for Table PAY_HISTORY
--------------------------------------------------------

  ALTER TABLE "PAY_HISTORY" MODIFY ("PRODUCT_NM" NOT NULL ENABLE);
  ALTER TABLE "PAY_HISTORY" MODIFY ("PAY_CODE" NOT NULL ENABLE);
  ALTER TABLE "PAY_HISTORY" ADD CONSTRAINT "PK_PAY_HISTORY" PRIMARY KEY ("PAY_CODE")
  USING INDEX  ENABLE;
