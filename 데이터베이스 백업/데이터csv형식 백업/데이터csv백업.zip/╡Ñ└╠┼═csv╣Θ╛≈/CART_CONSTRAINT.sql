--------------------------------------------------------
--  Constraints for Table CART
--------------------------------------------------------

  ALTER TABLE "CART" MODIFY ("CART_ID" NOT NULL ENABLE);
  ALTER TABLE "CART" MODIFY ("PRODUCT_NM" NOT NULL ENABLE);
  ALTER TABLE "CART" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "CART" ADD CONSTRAINT "PK_CART" PRIMARY KEY ("CART_ID")
  USING INDEX  ENABLE;
