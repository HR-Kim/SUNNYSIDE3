--------------------------------------------------------
--  DDL for Table BOXOFFICE
--------------------------------------------------------

  CREATE TABLE "BOXOFFICE" 
   (	"MOVIE_ID" VARCHAR2(20 BYTE), 
	"MOVIE_RANK" VARCHAR2(20 BYTE)
   ) ;

   COMMENT ON COLUMN "BOXOFFICE"."MOVIE_ID" IS '영화ID';
   COMMENT ON COLUMN "BOXOFFICE"."MOVIE_RANK" IS '순위';
   COMMENT ON TABLE "BOXOFFICE"  IS '박스오피스';
