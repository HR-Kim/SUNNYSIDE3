--------------------------------------------------------
--  DDL for Index PK_MAIN_IMAGE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MAIN_IMAGE" ON "MAIN_IMAGE" ("IMAGE_ID") 
  ;
