--------------------------------------------------------
--  DDL for Index PK_PHOTO_TICKET
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PHOTO_TICKET" ON "PHOTO_TICKET" ("TICKET_CODE") 
  ;
