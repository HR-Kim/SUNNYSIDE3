--------------------------------------------------------
--  DDL for Table REVIEW
--------------------------------------------------------

  CREATE TABLE "REVIEW" 
   (	"MOVIE_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(20 BYTE), 
	"CONTENTS" VARCHAR2(4000 CHAR), 
	"VISITOR_RATE" NUMBER(3,1), 
	"REG_DT" DATE
   ) ;

   COMMENT ON COLUMN "REVIEW"."MOVIE_ID" IS '영화ID';
   COMMENT ON COLUMN "REVIEW"."USER_ID" IS '회원ID';
   COMMENT ON COLUMN "REVIEW"."CONTENTS" IS '내용';
   COMMENT ON COLUMN "REVIEW"."VISITOR_RATE" IS '관람객 평점';
   COMMENT ON COLUMN "REVIEW"."REG_DT" IS '등록일';
   COMMENT ON TABLE "REVIEW"  IS '리뷰';
