--------------------------------------------------------
--  DDL for Table ROOM
--------------------------------------------------------

  CREATE TABLE "ROOM" 
   (	"BRANCH_ID" VARCHAR2(20 BYTE), 
	"ROOM_ID" VARCHAR2(20 BYTE), 
	"ROOM_NM" VARCHAR2(20 CHAR), 
	"TOTAL_SEAT" NUMBER(3,0), 
	"REST_SEAT" NUMBER(3,0)
   ) ;

   COMMENT ON COLUMN "ROOM"."BRANCH_ID" IS '지점ID';
   COMMENT ON COLUMN "ROOM"."ROOM_ID" IS '상영관ID';
   COMMENT ON COLUMN "ROOM"."ROOM_NM" IS '상영관명';
   COMMENT ON COLUMN "ROOM"."TOTAL_SEAT" IS '총좌석';
   COMMENT ON COLUMN "ROOM"."REST_SEAT" IS '잔여좌석';
   COMMENT ON TABLE "ROOM"  IS '상영관';
