--------------------------------------------------------
--  DDL for Table SEAT
--------------------------------------------------------

  CREATE TABLE "SEAT" 
   (	"BRANCH_ID" VARCHAR2(20 BYTE), 
	"ROOM_ID" VARCHAR2(20 BYTE), 
	"SEAT_NM" VARCHAR2(3 CHAR), 
	"SEAT_Y" VARCHAR2(1 CHAR), 
	"SEAT_X" NUMBER(2,0), 
	"USE_YN" VARCHAR2(2 CHAR)
   ) ;

   COMMENT ON COLUMN "SEAT"."BRANCH_ID" IS '지점ID';
   COMMENT ON COLUMN "SEAT"."ROOM_ID" IS '상영관ID';
   COMMENT ON COLUMN "SEAT"."SEAT_NM" IS '좌석명';
   COMMENT ON COLUMN "SEAT"."SEAT_Y" IS '좌석Y축';
   COMMENT ON COLUMN "SEAT"."SEAT_X" IS '좌석X축';
   COMMENT ON COLUMN "SEAT"."USE_YN" IS '사용여부';
   COMMENT ON TABLE "SEAT"  IS '좌석';
