--------------------------------------------------------
--  Ref Constraints for Table CODE
--------------------------------------------------------

  ALTER TABLE "CODE" ADD CONSTRAINT "FK_CODE_TYPE_TO_CODE" FOREIGN KEY ("CODE_TYPE_ID")
	  REFERENCES "CODE_TYPE" ("CODE_TYPE_ID") ENABLE;
