--------------------------------------------------------
--  Constraints for Table REVIEW
--------------------------------------------------------

  ALTER TABLE "REVIEW" MODIFY ("MOVIE_ID" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" MODIFY ("CONTENTS" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" ADD CONSTRAINT "PK_REVIEW" PRIMARY KEY ("MOVIE_ID", "USER_ID")
  USING INDEX  ENABLE;
