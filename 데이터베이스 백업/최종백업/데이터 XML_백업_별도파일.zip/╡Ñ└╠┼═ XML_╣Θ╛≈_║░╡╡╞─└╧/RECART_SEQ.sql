--------------------------------------------------------
--  DDL for Sequence RECART_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "RECART_SEQ"  MINVALUE 1 MAXVALUE 100000 INCREMENT BY 1 START WITH 101 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
