--------------------------------------------------------
--  Constraints for Table FAQ
--------------------------------------------------------

  ALTER TABLE "FAQ" MODIFY ("QUESTION_ID" NOT NULL ENABLE);
