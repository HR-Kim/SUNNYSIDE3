--------------------------------------------------------
--  DDL for Index PK_FILE_MNG
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FILE_MNG" ON "FILE_MNG" ("FILE_ID", "NUM") 
  ;
