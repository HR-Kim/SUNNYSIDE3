--------------------------------------------------------
--  DDL for Table CODE
--------------------------------------------------------

  CREATE TABLE "CODE" 
   (	"CODE_TYPE_ID" VARCHAR2(30 BYTE), 
	"CODE_ID" VARCHAR2(30 BYTE), 
	"CODE_NM" VARCHAR2(100 BYTE), 
	"USE_YN" CHAR(1 BYTE) DEFAULT 0, 
	"NUM" NUMBER(5,0), 
	"LVL" VARCHAR2(20 BYTE) DEFAULT '1', 
	"REG_DT" DATE, 
	"MOD_ID" VARCHAR2(20 BYTE), 
	"MOD_DT" DATE
   ) ;

   COMMENT ON COLUMN "CODE"."CODE_TYPE_ID" IS '코드유형ID';
   COMMENT ON COLUMN "CODE"."CODE_ID" IS '코드ID';
   COMMENT ON COLUMN "CODE"."CODE_NM" IS '코드명';
   COMMENT ON COLUMN "CODE"."USE_YN" IS '사용여부';
   COMMENT ON COLUMN "CODE"."NUM" IS '순서';
   COMMENT ON COLUMN "CODE"."LVL" IS '등급';
   COMMENT ON COLUMN "CODE"."REG_DT" IS '등록일';
   COMMENT ON COLUMN "CODE"."MOD_ID" IS '수정자ID';
   COMMENT ON COLUMN "CODE"."MOD_DT" IS '수정일';
   COMMENT ON TABLE "CODE"  IS '공통코드';
