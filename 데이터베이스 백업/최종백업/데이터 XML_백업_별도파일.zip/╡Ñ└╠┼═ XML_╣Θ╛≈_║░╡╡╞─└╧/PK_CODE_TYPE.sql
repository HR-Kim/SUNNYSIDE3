--------------------------------------------------------
--  DDL for Index PK_CODE_TYPE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CODE_TYPE" ON "CODE_TYPE" ("CODE_TYPE_ID") 
  ;
