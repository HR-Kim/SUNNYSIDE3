--------------------------------------------------------
--  DDL for Index PK_SEAT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_SEAT" ON "SEAT" ("BRANCH_ID", "ROOM_ID", "SEAT_NM") 
  ;
