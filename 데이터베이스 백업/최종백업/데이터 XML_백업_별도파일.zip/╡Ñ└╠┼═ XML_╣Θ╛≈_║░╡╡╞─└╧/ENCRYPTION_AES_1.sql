--------------------------------------------------------
--  DDL for Package Body ENCRYPTION_AES
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE PACKAGE BODY "ENCRYPTION_AES" 
IS

/******************************************************************************
  암호화
 ******************************************************************************/

 FUNCTION ENC_AES ( INPUT_STRING IN VARCHAR2
 ) RETURN VARCHAR2
 IS
    V_ORIGINAL_RAW      RAW(130);        -- 암호화 전 데이타
    V_KEY_DATA_RAW      RAW(64);        -- 키값
    ENCRYTED_RAW        RAW(320);        -- 암호화 된 데이타
    CONVERTED_STRING    VARCHAR2(320);   -- 형 변환 데이타
 
    BEGIN

        V_ORIGINAL_RAW   := UTL_I18N.STRING_TO_RAW(INPUT_STRING, 'AL32UTF8');         -- VARCHAR2 -> RAW 타입으로 변경 (변경 이유는 아래에..)        
        V_KEY_DATA_RAW   := UTL_I18N.STRING_TO_RAW('AKDKEKDKFKGKEKSD', 'AL32UTF8');   -- 키값 RAW 타입으로 변경.
        ENCRYTED_RAW     := DBMS_CRYPTO.ENCRYPT( SRC => V_ORIGINAL_RAW,
                                                    TYP => DBMS_CRYPTO.ENCRYPT_AES128 +
                                                           DBMS_CRYPTO.CHAIN_CBC +
                                                           DBMS_CRYPTO.PAD_PKCS5,
                                                    KEY => V_KEY_DATA_RAW );
        CONVERTED_STRING := UTL_RAW.cast_to_varchar2( utl_encode.base64_encode(ENCRYTED_RAW) ) ;

        -- 중요!!! raw 타입을 base64_encode()를 이용하여 encoding 후 varchar2 타입으로 변환해야한다!! 해주지 않으면
        -- ORA-06502: PL/SQL: numeric or value error: hex to raw conversion error 이러한 에러를 볼 수 있을 것이다.

        RETURN CONVERTED_STRING;

    END ENC_AES;

/******************************************************************************
  암호화 끝
 ******************************************************************************/

/******************************************************************************
  복호화
 ******************************************************************************/

 FUNCTION DEC_AES (  INPUT_STRING IN VARCHAR2
 ) RETURN VARCHAR2

 IS

    V_KEY_DATA_RAW      RAW(64);        -- 키값
    DECRYPTED_RAW       RAW(320);        -- 복호화 값
    CONVERTED_STRING    VARCHAR2(320);   -- 형 변환 데이타

    BEGIN

        V_KEY_DATA_RAW := UTL_I18N.STRING_TO_RAW('AKDKEKDKFKGKEKSD', 'AL32UTF8');
        DECRYPTED_RAW :=  DBMS_CRYPTO.DECRYPT( SRC => utl_encode.base64_decode(utl_raw.cast_to_raw(INPUT_STRING)),
        -- 중요!!! varchar2 타입의 데이타를 raw 타입으로 변환 후 decoding 해야한다!! 해주지 않으면
        -- ORA-06502: PL/SQL: numeric or value error: hex to raw conversion error 이러한 에러를 볼 수 있을 것이다.
                                                  TYP => DBMS_CRYPTO.ENCRYPT_AES128 +
                                                         DBMS_CRYPTO.CHAIN_CBC +
                                                         DBMS_CRYPTO.PAD_PKCS5,
                                                  KEY => V_KEY_DATA_RAW );                                        

        
        CONVERTED_STRING :=  UTL_I18N.RAW_TO_CHAR(DECRYPTED_RAW, 'AL32UTF8');  -- RAW -> CHAR 타입으로 변환하여 RETURN
        RETURN CONVERTED_STRING;
        RETURN CONVERTED_STRING;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
            CONVERTED_STRING:='NO_DATA_FOUND';
            RETURN 'NO_DATA_FOUND';
        WHEN PROGRAM_ERROR THEN
            DBMS_OUTPUT.PUT_LINE('PROGRAM_ERROR');
            CONVERTED_STRING:='PROGRAM_ERROR';
            RETURN 'PROGRAM_ERROR';
        WHEN OTHERS THEN   
            DBMS_OUTPUT.PUT_LINE('PROGRAM_ERROR: OTHERS'); 
            CONVERTED_STRING:='PROGRAM_ERROR: OTHERS';
            RETURN 'PROGRAM_ERROR: OTHERS';
    END DEC_AES;

/******************************************************************************
  복호화 끝
 ******************************************************************************/

END ENCRYPTION_AES;

/
