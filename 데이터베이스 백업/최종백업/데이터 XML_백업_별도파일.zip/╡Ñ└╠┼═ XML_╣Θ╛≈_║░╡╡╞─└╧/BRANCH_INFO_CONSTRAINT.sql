--------------------------------------------------------
--  Constraints for Table BRANCH_INFO
--------------------------------------------------------

  ALTER TABLE "BRANCH_INFO" MODIFY ("BRANCH_ID" NOT NULL ENABLE);
  ALTER TABLE "BRANCH_INFO" MODIFY ("BRANCH_NM" NOT NULL ENABLE);
  ALTER TABLE "BRANCH_INFO" ADD CONSTRAINT "PK_BRANCH_INFO" PRIMARY KEY ("BRANCH_ID")
  USING INDEX  ENABLE;
