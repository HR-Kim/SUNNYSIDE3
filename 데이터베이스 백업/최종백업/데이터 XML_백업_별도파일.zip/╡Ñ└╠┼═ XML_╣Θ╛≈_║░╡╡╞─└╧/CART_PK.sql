--------------------------------------------------------
--  DDL for Index CART_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "CART_PK" ON "CART" ("PRODUCT_ID", "CART_ID") 
  ;
