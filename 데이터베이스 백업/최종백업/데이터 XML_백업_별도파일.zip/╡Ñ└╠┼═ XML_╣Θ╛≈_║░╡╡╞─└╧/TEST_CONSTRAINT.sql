--------------------------------------------------------
--  Constraints for Table TEST
--------------------------------------------------------

  ALTER TABLE "TEST" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "TEST" ADD CONSTRAINT "TEST_PK" PRIMARY KEY ("NAME")
  USING INDEX  ENABLE;
