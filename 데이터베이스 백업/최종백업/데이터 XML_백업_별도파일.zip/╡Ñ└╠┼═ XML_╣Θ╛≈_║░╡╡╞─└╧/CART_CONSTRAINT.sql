--------------------------------------------------------
--  Constraints for Table CART
--------------------------------------------------------

  ALTER TABLE "CART" MODIFY ("CART_ID" NOT NULL ENABLE);
  ALTER TABLE "CART" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
  ALTER TABLE "CART" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "CART" ADD CONSTRAINT "CART_PK" PRIMARY KEY ("PRODUCT_ID", "CART_ID")
  USING INDEX  ENABLE;
