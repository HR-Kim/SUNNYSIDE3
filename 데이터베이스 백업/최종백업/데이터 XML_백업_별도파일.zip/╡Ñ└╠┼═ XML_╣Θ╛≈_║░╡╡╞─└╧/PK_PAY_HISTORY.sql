--------------------------------------------------------
--  DDL for Index PK_PAY_HISTORY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PAY_HISTORY" ON "PAY_HISTORY" ("PAY_CODE", "PRODUCT_ID") 
  ;
