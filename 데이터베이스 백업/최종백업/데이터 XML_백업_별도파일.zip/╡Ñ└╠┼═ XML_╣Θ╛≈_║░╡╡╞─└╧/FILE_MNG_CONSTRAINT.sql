--------------------------------------------------------
--  Constraints for Table FILE_MNG
--------------------------------------------------------

  ALTER TABLE "FILE_MNG" MODIFY ("FILE_ID" NOT NULL ENABLE);
  ALTER TABLE "FILE_MNG" MODIFY ("NUM" NOT NULL ENABLE);
  ALTER TABLE "FILE_MNG" ADD CONSTRAINT "PK_FILE_MNG" PRIMARY KEY ("FILE_ID", "NUM")
  USING INDEX  ENABLE;
