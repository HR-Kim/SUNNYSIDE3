--------------------------------------------------------
--  Constraints for Table USER_COUPON
--------------------------------------------------------

  ALTER TABLE "USER_COUPON" MODIFY ("COUPON_CODE" NOT NULL ENABLE);
  ALTER TABLE "USER_COUPON" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "USER_COUPON" ADD CONSTRAINT "PK_USER_COUPON" PRIMARY KEY ("COUPON_CODE")
  USING INDEX  ENABLE;
