--------------------------------------------------------
--  Constraints for Table CODE_TYPE
--------------------------------------------------------

  ALTER TABLE "CODE_TYPE" MODIFY ("CODE_TYPE_ID" NOT NULL ENABLE);
  ALTER TABLE "CODE_TYPE" MODIFY ("CODE_TYPE_NM" NOT NULL ENABLE);
  ALTER TABLE "CODE_TYPE" ADD CONSTRAINT "PK_CODE_TYPE" PRIMARY KEY ("CODE_TYPE_ID")
  USING INDEX  ENABLE;
